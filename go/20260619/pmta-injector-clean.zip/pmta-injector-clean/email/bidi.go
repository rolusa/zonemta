package email

import "strings"

// 【2026-06-15】字节反转隐藏(RLO 反指纹) —— 仅用于"主题 + 显示名"
//
// 机制：把文本按 rune 反转 + 前置 RLO(U+202E，强制从右到左覆盖显示) + 末尾 PDF(U+202C，关闭覆盖)。
//   - 收件人端：RLO 把"反转的字节"在显示时再反一次 → 字母/数字/CJK/邮箱等"非镜像"字符显示正常。
//   - 扫描器端：读到的原始字节是反序的 → 朴素子串关键词匹配失效。
//
// ⚠ 显示局限（RLO 固有，非 bug）：
//   ① 成对镜像字符（() [] <> {} 等 Bidi_Mirrored 字符）在 RTL 覆盖下会被镜像翻转：
//      原文 "A(B)C" 经反转 + RLO 显示后会变成 "A)B(C"（括号方向反了）。含括号/书名号的文本会错乱。
//   ② 按 rune 反转会拆散 emoji 的 ZWJ 组合序列（如家庭 emoji）/ 肤色修饰 / 变音符 → 这类字符显示可能错乱。
//      纯文字（CJK/拉丁/数字/常见标点）无影响。
//   故本功能仅建议用于"纯文字"的主题/显示名，含括号或 emoji 组合时慎用。
//
// 应用时机（见 builder.go）：在所有变量/模板替换之后、零宽字符之前。此刻已无 {变量} token，
//   变量早已被替换为值且能正常显示，故无需 LRI/PDI 隔离；变量"值"的字节一并反转（显示端由 RLO 还原正常）。
//
// 限制：RLO/PDF 是 Unicode 双向控制符，属 UTF-8 专属，Shift_JIS / ISO-2022-JP / EUC-JP / GBK 无法表示 →
//   调用方必须先用 bidiCharsetSupported 判定 charset，非 UTF-8 时跳过（否则转码会丢字符/变 ?）。
//
// 反指纹局限（已知）：成熟的 bidi-aware 扫描器会按显示顺序重建文本再扫描 → 可能仍命中关键词，且 RLO
//   本身是反垃圾高危特征，可能拉低送达率。本功能默认关闭，建议慎用/小批量实测。
//
// 注意：这里用 \u 转义而非字面控制符，避免真实 RLO/PDF 出现在源码里造成显示错乱。
const (
	bidiRLO rune = 0x202E // Right-to-Left Override（强制反转显示）
	bidiPDF rune = 0x202C // Pop Directional Formatting（关闭 RLO，防止影响后续内容如 <邮箱>）
)

// bidiReverseHide 对 text 做"字节反转 + RLO 回正"。空串原样返回。
func bidiReverseHide(text string) string {
	if text == "" {
		return text
	}
	runes := []rune(text)
	var sb strings.Builder
	sb.Grow(len(text) + 8)
	sb.WriteRune(bidiRLO)
	for i := len(runes) - 1; i >= 0; i-- {
		sb.WriteRune(runes[i])
	}
	sb.WriteRune(bidiPDF)
	return sb.String()
}

// bidiCharsetSupported 仅 UTF-8（含空串默认）支持 bidi 控制符；其它字符集无法编码这些字符。
func bidiCharsetSupported(charset string) bool {
	c := strings.ToUpper(strings.TrimSpace(charset))
	return c == "" || c == "UTF-8" || c == "UTF8"
}
