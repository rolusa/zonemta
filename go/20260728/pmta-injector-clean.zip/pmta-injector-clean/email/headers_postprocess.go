package email

// =============================================================================
// 【2026-05-31】邮件头后处理:字段名随机大小写 + 锚定式乱序
//
// 入口:在 builder.go::buildRawEmail 主头组装完成后,对累积的 []string mainHeaders 做后处理
//
// 配置:
//   - cfg.Headers.RandomCase    true → 应用 randomizeFieldNames
//   - cfg.Headers.ShuffleOrder  true → 应用 shuffleHeadersWithAnchors
//   - cfg.Headers.CaseMode      预留(D2 决策切换点):空="random"=全随机式;"stylepool" 留作未来扩展
//
// 锚定规则(温和模式):
//   priority 0  : x-virtual-mta / x-job        (PMTA 控制头,在最顶)
//   priority 1  : 所有 Received-*              (RFC 5321 时序要求)
//   priority 2  : DKIM-Signature               (紧随 Received 之后)
//   priority 3  : MIME-Version                 (在 body 前的 MIME 基础头)
//   priority 4  : From
//   priority 5  : To
//   priority 6  : Cc
//   priority 7  : Subject
//   priority 8  : Date
//   priority 9  : Message-ID
//   其它头     : 可乱序池(Fisher-Yates 洗牌)
//   特殊配对 : List-Unsubscribe + List-Unsubscribe-Post 配对锚定,Post 紧跟 Unsubscribe
//
// 大小写跳过名单(case-insensitive 比对):
//   DKIM-Signature  — simple canonicalization 字节比较,且伪签名失败原因要保持"链路损坏"语义
//   x-virtual-mta   — PMTA 控制头,字段名小写是 PMTA 配置约定
//   x-job           — 同上
//
// 设计原则:
//   - 不丢任何头(len(output) == len(input))
//   - 不重复任何头(每个输入头精确出现一次)
//   - Received-* 系列保持生成顺序(时序敏感)
//   - 大小写随机化后,锚定/配对识别用 strings.EqualFold(大小写不敏感)
//   - 所有随机源用传入的 *rand.Rand(worker 独立,避免共享种子污染)
// =============================================================================

import (
	"math/rand"
	"sort"
	"strings"
)

// caseSkipNames 字段名大小写随机化的跳过集合(全小写比对)
// 命中即保持原大小写,不参与随机化
//
// 设计:两个工程(PowerMTA / Haraka)共用同一份名单(联合集),保字节级一致
//   - dkim-signature   : DKIM simple canonicalization 字节比较兼容
//   - x-virtual-mta    : PowerMTA 控制头(Haraka 路径下永远不会出现 — 由 IsPMTA() 跳过)
//   - x-job            : 同上
//   - x-internal-ccbcc-skip-tg : Haraka log_delivered.js 插件依赖精确字段名扫描
//     (PowerMTA 路径下永远不会出现 — 由 SkipTelegram 字段控制)
var caseSkipNames = map[string]struct{}{
	"dkim-signature":           {},
	"x-virtual-mta":            {},
	"x-job":                    {},
	"x-internal-ccbcc-skip-tg": {},
}

// anchorPriority 温和锚定模式下,定位每类头到固定 priority(越小越靠前)
// 不在表里的头进入可乱序池
//
// 注意:"received" 是前缀匹配("Received:" 包括所有 ESP Received / Random Received / 原始 Received)
// 其它头是精确匹配
//
// 【2026-06-01 第三轮自检修复】mime-version 从 prio 3 改为 prio 10:
//
//	原因:builder.go::buildRawEmail 中 MIME-Version 是在 Message-ID 之后 append 的(L491 vs L486),
//	      如果 anchorPriority["mime-version"]=3,启用 ShuffleOrder 时 MIME-Version 会跑到 From 之前 —
//	      与"全关(ShuffleOrder=false)时按 append 顺序输出"的行为不一致,**同一发件方启用/关闭乱序
//	      会产生两类邮件特征**,反垃圾聚类时可能识别。
//	修复:prio 10 让 MIME-Version 锚定在 Message-ID(prio 9)之后,两种模式输出位置一致。
var anchorPriority = map[string]int{
	"x-virtual-mta":  0,
	"x-job":          0,
	"received":       1, // 前缀
	"dkim-signature": 2,
	"from":           4,
	"to":             5,
	"cc":             6,
	"subject":        7,
	"date":           8,
	"message-id":     9,
	"mime-version":   10, // 改:从 3 → 10,锚定在 Message-ID 之后
}

// splitHeaderBlock 把多个连续的邮件头(字符串块)按 RFC 5322 §2.2.3 折叠规则切成单条
// 续行(以 SP / TAB 开头的行)归属上一个头
//
// 输入示例(block):
//
//	"Received: from xxx\r\n (Authenticated...)\r\n by yyy\r\nFrom: a@b\r\n"
//
// 输出:
//
//	["Received: from xxx\r\n (Authenticated...)\r\n by yyy\r\n", "From: a@b\r\n"]
//
// 边界处理:
//   - 空字符串 → nil
//   - 末尾没有 \r\n 也能正确切分(SplitAfter 保留分隔符,无分隔符行原样保留)
//   - 多个连续空行不会合并(空行不归属任何头,直接丢弃)
func splitHeaderBlock(block string) []string {
	if block == "" {
		return nil
	}
	// 用 SplitAfter("\n") 保留 \n;\r\n 切分后每行末尾 = "\r\n";单 \n 行末尾 = "\n"
	lines := strings.SplitAfter(block, "\n")
	result := make([]string, 0, 16)
	var current strings.Builder
	for _, line := range lines {
		if line == "" {
			continue
		}
		// 空白行不参与累积也不分隔(罕见,但要兼容)
		// 注意:strings.TrimRight 后看是否空,但 "\r\n" trim 后为空也算空行
		if strings.TrimRight(line, "\r\n") == "" {
			continue
		}
		if current.Len() == 0 {
			current.WriteString(line)
			continue
		}
		// 折叠续行:首字符是 SP / TAB
		first := line[0]
		if first == ' ' || first == '\t' {
			current.WriteString(line)
		} else {
			result = append(result, current.String())
			current.Reset()
			current.WriteString(line)
		}
	}
	if current.Len() > 0 {
		result = append(result, current.String())
	}
	return result
}

// extractFieldName 从一个完整 header 条目("Name: value\r\n..." 含可能的折叠续行)提取字段名(小写)
// 续行(SP/TAB 开头)返回空字符串(理论上不会传入,但防御性处理)
// 无冒号返回空字符串
func extractFieldName(line string) string {
	if line == "" {
		return ""
	}
	if line[0] == ' ' || line[0] == '\t' {
		return ""
	}
	colon := strings.IndexByte(line, ':')
	if colon <= 0 {
		return ""
	}
	return strings.ToLower(strings.TrimSpace(line[:colon]))
}

// randomizeFieldName 把一个 header 条目的字段名("Name" 在 ":" 之前)逐字符随机大小写
// 跳过 caseSkipNames 中的字段(DKIM-Signature / x-virtual-mta / x-job)
// 值部分(冒号之后,包括折叠续行)完全不动
// 续行(SP/TAB 开头)原样返回
func randomizeFieldName(line string, r *rand.Rand) string {
	if line == "" || line[0] == ' ' || line[0] == '\t' {
		return line
	}
	colon := strings.IndexByte(line, ':')
	if colon <= 0 {
		return line
	}
	name := line[:colon]
	if _, skip := caseSkipNames[strings.ToLower(strings.TrimSpace(name))]; skip {
		return line
	}
	var sb strings.Builder
	sb.Grow(len(line))
	for i := 0; i < len(name); i++ {
		ch := name[i]
		isLower := ch >= 'a' && ch <= 'z'
		isUpper := ch >= 'A' && ch <= 'Z'
		if !isLower && !isUpper {
			// 数字、连字符 -、点 . 等保持原样
			sb.WriteByte(ch)
			continue
		}
		// 50/50 翻转
		if safeIntn(r, 2) == 0 {
			// 取大写
			if isLower {
				sb.WriteByte(ch - 32)
			} else {
				sb.WriteByte(ch)
			}
		} else {
			// 取小写
			if isUpper {
				sb.WriteByte(ch + 32)
			} else {
				sb.WriteByte(ch)
			}
		}
	}
	// 拼上 ":" 及后续(包括所有折叠续行)
	sb.WriteString(line[colon:])
	return sb.String()
}

// applyCaseRandomization 对整个 mainHeaders 切片做字段名大小写随机化
// 输入切片就地修改(返回同一切片,方便链式)
// 预留 caseMode 切换点:目前只走 "random" 路径
func applyCaseRandomization(headers []string, r *rand.Rand, caseMode string) []string {
	_ = caseMode // 预留:未来可扩展 "stylepool"(真实风格池)等
	if len(headers) == 0 {
		return headers
	}
	for i, h := range headers {
		headers[i] = randomizeFieldName(h, r)
	}
	return headers
}

// shuffleHeadersWithAnchors 锚定式乱序
// 算法:
//  1. 分离锚定头(anchorPriority 命中)和可乱序头
//  2. 把 List-Unsubscribe-Post 从可乱序池暂时分离(独立处理)
//  3. Fisher-Yates 洗牌可乱序池
//  4. 找 List-Unsubscribe 位置,后面插回 List-Unsubscribe-Post(若 LU 不存在则追加到末尾)
//  5. 锚定头按 priority 升序排,priority 相同时按原始 index 升序(同 priority 保持生成顺序)
//  6. 输出 = 锚定头序列 + 洗牌后的可乱序池
//
// 不变量:len(output) == len(input);output 元素集合 == input 元素集合(无丢失无重复)
func shuffleHeadersWithAnchors(headers []string, r *rand.Rand) []string {
	if len(headers) <= 1 {
		return headers
	}

	type anchoredHeader struct {
		line      string
		priority  int
		origIndex int
	}
	anchors := make([]anchoredHeader, 0, len(headers))
	pool := make([]string, 0, len(headers))
	var listUnsubPost string // 单独捕获 list-unsubscribe-post

	for i, h := range headers {
		name := extractFieldName(h)
		if name == "" {
			// 异常条目(无字段名),保守地放进可乱池
			pool = append(pool, h)
			continue
		}
		// Received 系列(包括 ESP Received / Random Received / 原始 Received)前缀匹配
		if strings.HasPrefix(name, "received") {
			anchors = append(anchors, anchoredHeader{h, anchorPriority["received"], i})
			continue
		}
		// 精确匹配
		if prio, ok := anchorPriority[name]; ok {
			anchors = append(anchors, anchoredHeader{h, prio, i})
			continue
		}
		// 特殊配对:list-unsubscribe-post 暂时拿出
		if name == "list-unsubscribe-post" {
			// 多个 Post 头理论上不会出现,但兼容性保留最后一个
			listUnsubPost = h
			continue
		}
		// 其它头进入可乱池
		pool = append(pool, h)
	}

	// Fisher-Yates 洗牌可乱池(safeIntn 防 r.Intn 越界)
	for i := len(pool) - 1; i > 0; i-- {
		j := safeIntn(r, i+1)
		pool[i], pool[j] = pool[j], pool[i]
	}

	// 把 list-unsubscribe-post 插回 list-unsubscribe 之后
	// 注意:list-unsubscribe 也可能在 pool 里(它不属于锚定头)
	if listUnsubPost != "" {
		insertIdx := -1
		for i, h := range pool {
			if extractFieldName(h) == "list-unsubscribe" {
				insertIdx = i + 1
				break
			}
		}
		if insertIdx >= 0 {
			// 在 pool[insertIdx] 位置插入 listUnsubPost
			newPool := make([]string, 0, len(pool)+1)
			newPool = append(newPool, pool[:insertIdx]...)
			newPool = append(newPool, listUnsubPost)
			newPool = append(newPool, pool[insertIdx:]...)
			pool = newPool
		} else {
			// 没有 List-Unsubscribe 但有 Post(异常,但兼容性处理):追加到末尾
			pool = append(pool, listUnsubPost)
		}
	}

	// 锚定头按 priority 升序;同 priority 按原 index 升序保稳定
	sort.SliceStable(anchors, func(i, j int) bool {
		if anchors[i].priority != anchors[j].priority {
			return anchors[i].priority < anchors[j].priority
		}
		return anchors[i].origIndex < anchors[j].origIndex
	})

	// 组装输出
	result := make([]string, 0, len(headers))
	for _, a := range anchors {
		result = append(result, a.line)
	}
	result = append(result, pool...)
	return result
}

// =============================================================================
// 【2026-07-25 从 PMTA 移植 方案 D】reorderByDkimList
//
// 目的:让 Go 端邮件里 header 按用户在 UI 里选的 DKIM h= 字段顺序输出。
// 收益:PMTA 5.0r8 会按邮件里 header 出现顺序生成 DKIM-Signature 的 h= →
//       最终 h= 顺序 = 用户 UI 选的顺序(比如"日本 SoftBank 风格")。
//
// 【Haraka 端特殊说明】
//   Haraka 真 DKIM 签名走 dkim_sign plugin,h= 由 /root/haraka/config/dkim_sign.ini::headers_to_sign
//   硬编码决定(与邮件里 header 顺序无关)。所以本函数在 Haraka 端只影响:
//     · 邮件表面 header 顺序(接收方看到的 raw header 顺序)
//     · Go 端方案 B 伪 DKIM 头(手动构造,受 header 顺序影响)
//   PMTA 端才有"控制邮件 header 顺序 = 控制 DKIM h= 顺序"的联动效果。
//
// 算法:
//  1. 分离"顶部锚定头"(x-virtual-mta / x-job / Received-* / DKIM-Signature 方案 B 伪签)
//  2. 按 dkimList 顺序,把邮件里能匹配的字段放进 dkimSlots[]
//     — 大小写不敏感匹配(strings.ToLower 比对)
//     — dkimList 里有但邮件没的字段:该 slot 保持空(输出时跳过,不影响)
//     — 邮件里有但 dkimList 没的字段:进 others 池
//  3. 输出 = 顶部锚定头 + dkimSlots(去空) + others(保持原相对顺序)
//
// 不变量:
//   - len(output) == len(input)(不丢头)
//   - 每个输入头精确出现一次(不重复)
//   - 顶部锚定头顺序不变
//   - dkimList 里未匹配的 slot 不占位(输出时跳过)
//
// 边界:
//   - dkimList 为空 → 返回原 headers 不变
//   - headers 为空 → 返回原空切片
// =============================================================================

// reorderByDkimList 按 dkimList 顺序重排 headers,保留顶部锚定头不动
func reorderByDkimList(headers []string, dkimList []string) []string {
	if len(headers) == 0 || len(dkimList) == 0 {
		return headers
	}

	// 顶部锚定头名单(小写比对):PMTA 控制头 + 时序头 + Go 端方案 B 伪 DKIM
	// 与 shuffleHeadersWithAnchors 里的 anchorPriority 表前 3 类保持一致
	topAnchorNames := map[string]struct{}{
		"x-virtual-mta":  {},
		"x-job":          {},
		"dkim-signature": {}, // 方案 B 伪 DKIM(生成在 mainHeaders 里,不是 MTA 加的真 DKIM)
	}

	// 建 dkim 字段名 → list 位置的映射(大小写不敏感 + 去空白)
	// 若 dkimList 内含重复,后者覆盖前者(最后一次匹配的字段占位)
	dkimIndex := make(map[string]int, len(dkimList))
	for i, name := range dkimList {
		key := strings.ToLower(strings.TrimSpace(name))
		if key == "" {
			continue
		}
		dkimIndex[key] = i
	}
	if len(dkimIndex) == 0 {
		// 全是空/空白 → 返回原 headers,防御性
		return headers
	}

	topAnchors := make([]string, 0, 8)
	dkimSlots := make([]string, len(dkimList)) // 按 dkimList 位置填充
	others := make([]string, 0, len(headers))

	for _, h := range headers {
		name := extractFieldName(h) // 已有函数,返回小写、去空白
		if name == "" {
			// 异常条目(无字段名 / 续行 line)→ 放入 others 保守处理
			others = append(others, h)
			continue
		}
		// 顶部锚定头(x-virtual-mta / x-job / Received-* / DKIM-Signature 方案 B 伪签)
		if _, isTop := topAnchorNames[name]; isTop {
			topAnchors = append(topAnchors, h)
			continue
		}
		if strings.HasPrefix(name, "received") {
			topAnchors = append(topAnchors, h)
			continue
		}
		// 在 dkim list 里的字段 → 放对应 slot
		if idx, ok := dkimIndex[name]; ok {
			dkimSlots[idx] = h
			continue
		}
		// 其他头
		others = append(others, h)
	}

	// 组装输出:topAnchors(保原序) + dkimSlots(按 list 顺序,跳过空 slot) + others(保原序)
	result := make([]string, 0, len(headers))
	result = append(result, topAnchors...)
	for _, h := range dkimSlots {
		if h != "" {
			result = append(result, h)
		}
	}
	result = append(result, others...)
	return result
}

// PostprocessMainHeaders 总入口,builder.go 调用
// 顺序:先乱序/dkim排序,后随机大小写
//
//	理由:乱序时用 strings.EqualFold 比对字段名(大小写不敏感),即使先大小写化也不会失效;
//	      但先乱序保持锚定逻辑的字段名原始大小写形式(更不容易出 bug),所以选先乱序
//
// 【2026-07-25 从 PMTA 移植 方案 D】新增 dkimList 参数:
//   - dkimList 非空 → 优先按 dkimList 顺序重排(reorderByDkimList),**跳过 shuffleOrder**
//     理由:DKIM 排序 = 顺序确定性;shuffleOrder = 随机顺序。两者本质矛盾,确定性优先。
//   - dkimList 为空(用户未启用 DKIM h= 自定义)→ 走老逻辑(shuffle 如启用)
//   - randomCase 独立生效(大小写与顺序正交)
//
// 注意:输入 headers 切片可能被就地修改(乱序时返回新切片,大小写随机化时就地修改)
func PostprocessMainHeaders(headers []string, r *rand.Rand, shuffleOrder, randomCase bool, caseMode string, dkimList []string) []string {
	if len(headers) == 0 {
		return headers
	}
	// 【2026-07-25 方案 D】DKIM 排序优先:非空时按 dkimList 顺序重排,跳过 shuffle
	if len(dkimList) > 0 {
		headers = reorderByDkimList(headers, dkimList)
	} else if shuffleOrder {
		headers = shuffleHeadersWithAnchors(headers, r)
	}
	if randomCase {
		headers = applyCaseRandomization(headers, r, caseMode)
	}
	return headers
}
