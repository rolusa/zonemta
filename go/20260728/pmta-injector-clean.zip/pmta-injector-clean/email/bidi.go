package email

import "strings"

// 【2026-06-15】字节反转隐藏(RLO 反指纹) —— 仅用于"主题 + 显示名"
// 【2026-07-09 升级】改用 LRI/PDI 隔离段包裹（对齐朋友字节格式 + Unicode 6.3+ 官方推荐做法）
//
// 输出格式：[LRI(U+2066)][RLO(U+202E)][rune 反序内容][PDF(U+202C)][PDI(U+2069)]
//   - LRI/PDI：Unicode 6.3+ 引入的"隔离"控制符，把整段视为独立方向段，外围文本（如后续 <邮箱@域>、
//     Subject 后续内容）完全不受内部 RLO 影响 —— 这是解决 v1 RLO/PDF 段落被邮箱地址"漏出去反转"的关键。
//   - RLO/PDF：在隔离段内部把 rune 反序内容视觉再反一次 → 字母/数字/CJK 等"非镜像"字符显示正常。
//   - 扫描器端：读到的原始字节是反序的 → 朴素子串关键词匹配失效。
//
// ⚠ 显示局限（RLO 固有，非 bug）：
//   ① 成对镜像字符（() [] <> {} 等 Bidi_Mirrored 字符）在 RTL 覆盖下会被镜像翻转：
//      原文 "A(B)C" 经反转 + RLO 显示后会变成 "A)B(C"（括号方向反了）。含括号/书名号的文本会错乱。
//   ② 按 rune 反转会拆散 emoji 的 ZWJ 组合序列（如家庭 emoji）/ 肤色修饰 / 变音符 → 这类字符显示可能错乱。
//      纯文字（CJK/拉丁/数字/常见标点）无影响。
//   故本功能仅建议用于"纯文字"的主题/显示名，含括号或 emoji 组合时慎用。
//
// 应用时机（见 builder.go）：文本 → 变量/模板替换 → 零宽字符插入（如启用）→ 本函数（最后一道）。
//   顺序含义：零宽字符跟原文一起被反转，视觉上零宽字符仍落在"字母之间"的合理位置；且 RLO 段落内
//   不会因零宽字符（BN 类 Boundary Neutral）打断 bidi 计算 → 视觉正确 + 反指纹叠加。
//
// 限制：LRI/RLO/PDF/PDI 是 Unicode 双向控制符，属 UTF-8 专属，Shift_JIS / ISO-2022-JP / EUC-JP / GBK 无法表示 →
//   调用方必须先用 bidiCharsetSupported 判定 charset，非 UTF-8 时跳过（否则转码会丢字符/变 ?）。
//
// 反指纹局限（已知）：成熟的 bidi-aware 扫描器会按显示顺序重建文本再扫描 → 可能仍命中关键词，且 RLO
//   本身是反垃圾高危特征，可能拉低送达率。本功能默认关闭，建议慎用/小批量实测。
//
// 注意：这里用 \u 转义而非字面控制符，避免真实 RLO/PDF 出现在源码里造成显示错乱。
const (
	bidiLRI rune = 0x2066 // Left-to-Right Isolate（开启方向隔离段，外围不受内部 RLO 影响）
	bidiRLO rune = 0x202E // Right-to-Left Override（强制反转显示）
	bidiPDF rune = 0x202C // Pop Directional Formatting（关闭 RLO 覆盖）
	bidiPDI rune = 0x2069 // Pop Directional Isolate（关闭 LRI 隔离段）
)

// bidiReverseHide 对 text 做"rune 反序 + LRI/PDI 隔离包裹"。空串原样返回。
// 输出格式：[LRI][RLO][rune 反序内容][PDF][PDI]（4 个 rune 控制符各 3 字节 UTF-8，共 12 字节额外开销）
func bidiReverseHide(text string) string {
	if text == "" {
		return text
	}
	runes := []rune(text)
	var sb strings.Builder
	sb.Grow(len(text) + 16) // 4 控制符 × 3 字节 = 12，留 4 字节余量
	sb.WriteRune(bidiLRI)
	sb.WriteRune(bidiRLO)
	for i := len(runes) - 1; i >= 0; i-- {
		sb.WriteRune(runes[i])
	}
	sb.WriteRune(bidiPDF)
	sb.WriteRune(bidiPDI)
	return sb.String()
}

// bidiCharsetSupported 仅 UTF-8（含空串默认）支持 bidi 控制符；其它字符集无法编码这些字符。
func bidiCharsetSupported(charset string) bool {
	c := strings.ToUpper(strings.TrimSpace(charset))
	return c == "" || c == "UTF-8" || c == "UTF8"
}
